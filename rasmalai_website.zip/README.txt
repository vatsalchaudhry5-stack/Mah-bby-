# Rasmalai 💋 — Personal Website

Open `index.html` in a browser to preview it.

## Publish for free with GitHub Pages
1. Create/sign into a GitHub account.
2. Create a new public repository (for example `rasmalai`).
3. Upload `index.html`.
4. Open the repository's Settings → Pages.
5. Choose **Deploy from a branch**, select `main` and `/root`, then Save.
6. GitHub will give you a free `github.io` website link.

## Song
The site currently has a Spotify search link for “I Wanna Be Yours”. Replace the `href` on the Play button with your own legitimate streaming URL if you want a specific version.

## Secrets
Five clickable Easter eggs are included. Progress is stored in the browser with localStorage.
